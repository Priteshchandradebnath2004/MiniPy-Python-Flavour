# MiniPy – Customized Python-Derived Language

MiniPy is a small educational language prototype inspired by Python. It uses a simple interpreter written in Python and provides five custom built-in function names.

## Five custom built-in functions

| Custom function | Purpose | Example |
|---|---|---|
| `pika(value)` | Displays a value on the screen (like Python's `print()`) | `pika("Hello")` |
| `mesh(prompt)` | Accepts text input (like Python's `input()`) | `name = mesh("Your name: ")` |
| `ray(a, b)` | Adds two values | `ray(10, 5)` returns `15` |
| `subi(a, b)` | Multiplies two values | `subi(10, 5)` returns `50` |
| `yaki(a)` | Calculates the square of a number | `yaki(10)` returns `100` |

## Run the project

1. Install Python 3.
2. Open a terminal or Command Prompt in this folder.
3. Run:

```bash
python minipy.py example.mpy
```

MiniPy programs use the `.mpy` extension. The included `example.mpy` demonstrates all five custom functions.

## Supported features

- Assigning values to variables, such as `x = 10`
- Numbers and quoted text
- The five custom built-in functions listed above
- Basic arithmetic expressions using `+`, `-`, `*`, and `/`

This is a small educational prototype, not a complete replacement for Python or CPython.
