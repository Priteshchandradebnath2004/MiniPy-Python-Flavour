"""\
MiniPy: a tiny Python-derived language prototype.

Custom built-ins:
    pika(value)       -> print a value
    mesh(prompt)      -> read text input
    ray(a, b)         -> add two values
    subi(a, b)        -> multiply two values
    yaki(a)           -> square a value

Run: python minipy.py example.mpy
"""
import ast
import sys
from pathlib import Path


def run_file(filename):
    variables = {}

    def evaluate(node):
        if isinstance(node, ast.Constant):
            return node.value

        if isinstance(node, ast.Name):
            if node.id in variables:
                return variables[node.id]
            raise NameError(f"Unknown variable: {node.id}")

        if isinstance(node, ast.BinOp):
            left, right = evaluate(node.left), evaluate(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
            raise ValueError("Operator not supported")

        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return -evaluate(node.operand)

        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            name = node.func.id
            args = [evaluate(arg) for arg in node.args]

            if name == "pika" and len(args) == 1:
                print(args[0])
                return None
            if name == "mesh" and len(args) == 1:
                return input(str(args[0]))
            if name == "ray" and len(args) == 2:
                return args[0] + args[1]
            if name == "subi" and len(args) == 2:
                return args[0] * args[1]
            if name == "yaki" and len(args) == 1:
                return args[0] ** 2

            raise ValueError(f"Unknown function or incorrect arguments: {name}")

        raise ValueError("This MiniPy expression is not supported")

    try:
        source = Path(filename).read_text(encoding="utf-8")
        tree = ast.parse(source, filename=filename)

        for statement in tree.body:
            if isinstance(statement, ast.Assign) and len(statement.targets) == 1:
                target = statement.targets[0]
                if not isinstance(target, ast.Name):
                    raise ValueError("Only simple variable assignments are supported")
                variables[target.id] = evaluate(statement.value)
            elif isinstance(statement, ast.Expr):
                evaluate(statement.value)
            else:
                raise ValueError("Only variable assignments and function calls are supported")

    except (OSError, SyntaxError, NameError, ValueError, TypeError, ZeroDivisionError) as error:
        print(f"MiniPy error: {error}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python minipy.py <program.mpy>")
        sys.exit(1)
    run_file(sys.argv[1])
